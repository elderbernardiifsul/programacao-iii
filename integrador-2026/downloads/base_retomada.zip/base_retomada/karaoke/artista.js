// karaoke/artista.js — Classe Artista (nova na Unidade 3)

class Artista {
    constructor(nome, id) {
        this.nome = nome;
        this.id = id || null;
    }
}

module.exports = { Artista };
