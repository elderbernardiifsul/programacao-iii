
class Musica {

    // artista agora é um objeto da classe Artista (antes era só um texto)
    constructor(nome, artista, id) {
        //atributos com this.atrib
        this.nome = nome;
        this.artista = artista;
        this.partes = []; // associacao com Parte
        if(!id){ //sem id definido
            this.id=null;
        }else{
            this.id = id;
        }
    }

    //metodos
    addParte(parte) { //parte é objeto de Parte
        try {
            // valida parte
            if( !parte.letra || !parte.tempoEspera || !parte.tag ){
                // parte tem problema
                throw new Error("Parte da Musica com problema!");
                
            }
            // armazena parte em partes
            this.partes.push(parte);

        } catch (error) {
            console.log("Erro ao addParte: " + error.message);
        }
    }

    getLetraInteira(){
        // this.partes -->todas as partes

        let letra = "";

        this.partes.forEach((parte) => {
            letra += parte.letra;
        });
        return letra;
    }
}

module.exports = {Musica};
